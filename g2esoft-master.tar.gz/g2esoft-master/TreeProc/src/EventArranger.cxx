// EventArranger.cxx

#include "TreeProc/EventArranger.h"

using namespace std;
using namespace TreeProc;

// EventArranger implementation
EventArranger::EventArranger(const char *procName, const char *instName) : _procName(procName), _instName(instName) {}
